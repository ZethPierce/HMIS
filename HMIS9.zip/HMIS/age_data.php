<?php

include('connection.php');
$hexa = array(
    "(255, 99, 132, 1)",
    "(54, 162, 235, 1)",
    "(255, 206, 86, 1)",
    "(75, 192, 192, 1)",
    "(153, 102, 255, 1)",
    "(255, 159, 64, 1)",
    "(255, 99, 132, 1)",
    "(54, 162, 235, 1)",
    "(255, 99, 132, 1)",
    "(54, 162, 235, 1)"
);

if (isset($_POST["action"])) {

    if ($_POST["action"] == 'age') {
        $query = "SELECT age, count(*) as number FROM users GROUP BY age ";

        $result = mysqli_query($conn, $query);

        $data = array();

        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = array(
                'age'       => $row["age"],
                'number'    => $row["number"],
                'color'     => 'rgba' . $hexa[array_rand($hexa)] . ''
            );
        }

        echo json_encode($data);
    }
}

?>
