-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2023 at 05:11 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmis_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '$2y$10$lvBXIolFQqmeHJzhjo06BOsa5UiUtE42w78ziu9tdhghlR/Ynswzu'),
(2, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(3, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(4, 'lastica', 'mark', 'aldrin', 'users', 'user'),
(5, 'newonly', 'newonly', 'newonly', 'newonly', '$2y$10$wn3pCl3.VPv7l8MKsx5gxe/EyKIdNYQxGciZiP4ezyLGpzTQG5yUa'),
(6, 'pogi', 'miguelfranz', '321e', '321e', '$2y$10$hALq9R0y0kCairlanN3xv.cNpkiyBWaY.9CEGzzY7yBz2ii5sIBKa'),
(7, 'b1322', 'b132', 'b132', 'b132', '$2y$10$XBB5l.kcy/yrjH1Y/jWr1.LS8hJP.4WLtbn/hKmxS2iJWAkmdfDH.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_damages`
--

CREATE TABLE `tbl_admin_damages` (
  `id` int(50) NOT NULL,
  `city` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `areas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_damages`
--

INSERT INTO `tbl_admin_damages` (`id`, `city`, `total`, `description`, `areas`) VALUES
(1, 'm123', 'm124', 'm123m', 'm124\r\n'),
(2, 'm123999', 'm12399', 'm123991', 'm123994\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_casualties`
--

CREATE TABLE `tbl_casualties` (
  `id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `cause` varchar(50) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_disaster`
--

CREATE TABLE `tbl_disaster` (
  `id` int(55) NOT NULL,
  `area` varchar(200) NOT NULL,
  `person` varchar(200) NOT NULL,
  `fam` varchar(200) NOT NULL,
  `fam_inside_evac` varchar(200) NOT NULL,
  `person_inside_evac` varchar(200) NOT NULL,
  `fam_outside_evac` varchar(200) NOT NULL,
  `person_outside_evac` varchar(200) NOT NULL,
  `fam_total` varchar(200) NOT NULL,
  `person_total` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_disaster`
--

INSERT INTO `tbl_disaster` (`id`, `area`, `person`, `fam`, `fam_inside_evac`, `person_inside_evac`, `fam_outside_evac`, `person_outside_evac`, `fam_total`, `person_total`) VALUES
(1, '123', '123', '123', '123', '123', '123', '123', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `section`) VALUES
(1, 'user', 'user', 'user', 'user', '$2y$10$MOOOrssDON3cK3b8a6Ehxeu.sQwBhjs86g/H0G2.T9lV6q2ooQuxO', 'user'),
(2, 'awa', 'awa', 'awa', 'awa', 'awa', 'awa'),
(3, 'pogi', 'miguelfranz', '321', '1231', '1231', 'NULL'),
(4, 'tests', 'tests', '123', '123', '$2y$10$/54ZhDq7pcaQv6diqOBRUujk/.8mOqLB5btN5ZL6ErmGNAZoMd8JC', 'NULL'),
(6, '1111', '1111', '1111', '1111', '$2y$10$QsG0B/7srErvncV0YusKCueDrR4eH85Rm.fGQwOuh6Rcud0U5BBBu', 'NULL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin_damages`
--
ALTER TABLE `tbl_admin_damages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_disaster`
--
ALTER TABLE `tbl_disaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_admin_damages`
--
ALTER TABLE `tbl_admin_damages`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_disaster`
--
ALTER TABLE `tbl_disaster`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
