-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2023 at 12:10 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmis_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accident`
--

CREATE TABLE `tbl_accident` (
  `id` int(55) NOT NULL,
  `area` varchar(200) NOT NULL,
  `time_date` varchar(200) NOT NULL,
  `description` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_accident`
--

INSERT INTO `tbl_accident` (`id`, `area`, `time_date`, `description`, `remarks`) VALUES
(1, '123', '123', '123', '123'),
(2, '321', '321', '321', '321'),
(3, '1111', '2222', '33335', '4444'),
(4, '123', '2023-06-14T16:07', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '$2y$10$lvBXIolFQqmeHJzhjo06BOsa5UiUtE42w78ziu9tdhghlR/Ynswzu'),
(2, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(3, 'lastica', 'mark', 'aldrin', 'user', 'user'),
(4, 'lastica', 'mark', 'aldrin', 'users', 'user'),
(5, 'newonly', 'newonly', 'newonly', 'newonly', '$2y$10$wn3pCl3.VPv7l8MKsx5gxe/EyKIdNYQxGciZiP4ezyLGpzTQG5yUa'),
(6, 'pogi', 'miguelfranz', '321e', '321e', '$2y$10$hALq9R0y0kCairlanN3xv.cNpkiyBWaY.9CEGzzY7yBz2ii5sIBKa'),
(7, 'b1322', 'b132', 'b132', 'b132', '$2y$10$XBB5l.kcy/yrjH1Y/jWr1.LS8hJP.4WLtbn/hKmxS2iJWAkmdfDH.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_damages`
--

CREATE TABLE `tbl_admin_damages` (
  `id` int(50) NOT NULL,
  `city` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `areas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin_damages`
--

INSERT INTO `tbl_admin_damages` (`id`, `city`, `total`, `description`, `areas`) VALUES
(1, 'm123', 'm124', 'm123m', 'm124\r\n'),
(2, 'm123999', 'm12399', 'm123991', 'm123994\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_casualties`
--

CREATE TABLE `tbl_casualties` (
  `id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `cause` varchar(50) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_casualties`
--

INSERT INTO `tbl_casualties` (`id`, `name`, `age`, `sex`, `address`, `cause`, `remarks`, `status`) VALUES
(1, '123', '123', '123', '123', '123', '123', '12343'),
(2, '123', '123', '123123', '1312313', '1313', '213123', 'Injured');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_covid19`
--

CREATE TABLE `tbl_covid19` (
  `id` int(50) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `contact_no` varchar(55) NOT NULL,
  `address` varchar(255) NOT NULL,
  `destination_address` varchar(255) NOT NULL,
  `arrival_date` varchar(200) NOT NULL,
  `plate_number` varchar(25) NOT NULL,
  `contact_person` varchar(55) NOT NULL,
  `contact_person_number` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_covid19`
--

INSERT INTO `tbl_covid19` (`id`, `first_name`, `middle_name`, `last_name`, `contact_no`, `address`, `destination_address`, `arrival_date`, `plate_number`, `contact_person`, `contact_person_number`) VALUES
(1, '111', '222', '333', '444', '555', '666', '777', '8882', '999', '000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_damages`
--

CREATE TABLE `tbl_damages` (
  `id` int(55) NOT NULL,
  `city` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `totally` varchar(255) NOT NULL,
  `partially` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_damages`
--

INSERT INTO `tbl_damages` (`id`, `city`, `total`, `totally`, `partially`) VALUES
(1, '444', '444', '444', '444');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_disaster`
--

CREATE TABLE `tbl_disaster` (
  `id` int(55) NOT NULL,
  `area` varchar(200) NOT NULL,
  `person` varchar(200) NOT NULL,
  `fam` varchar(200) NOT NULL,
  `fam_inside_evac` varchar(200) NOT NULL,
  `person_inside_evac` varchar(200) NOT NULL,
  `fam_outside_evac` varchar(200) NOT NULL,
  `person_outside_evac` varchar(200) NOT NULL,
  `fam_total` varchar(200) NOT NULL,
  `person_total` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_disaster`
--

INSERT INTO `tbl_disaster` (`id`, `area`, `person`, `fam`, `fam_inside_evac`, `person_inside_evac`, `fam_outside_evac`, `person_outside_evac`, `fam_total`, `person_total`) VALUES
(1, '123', '123', '123', '123', '123', '123', '123', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lifelines_communication`
--

CREATE TABLE `tbl_lifelines_communication` (
  `id` int(55) NOT NULL,
  `area` varchar(255) NOT NULL,
  `date_time_interruption` varchar(200) NOT NULL,
  `date_time_restored` varchar(200) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_lifelines_communication`
--

INSERT INTO `tbl_lifelines_communication` (`id`, `area`, `date_time_interruption`, `date_time_restored`, `remarks`) VALUES
(1, '1g321', '2023-06-22T04:53', '2023-06-29T04:53', 'g32131');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lifelines_dam`
--

CREATE TABLE `tbl_lifelines_dam` (
  `id` int(55) NOT NULL,
  `level` varchar(255) NOT NULL,
  `inflow` varchar(255) NOT NULL,
  `outflow` varchar(255) NOT NULL,
  `gate_open` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_lifelines_dam`
--

INSERT INTO `tbl_lifelines_dam` (`id`, `level`, `inflow`, `outflow`, `gate_open`) VALUES
(1, '123', '123', '123', '321');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lifelines_power_supply`
--

CREATE TABLE `tbl_lifelines_power_supply` (
  `id` int(55) NOT NULL,
  `area` varchar(255) NOT NULL,
  `date_time_interruption` varchar(200) NOT NULL,
  `date_time_restored` varchar(200) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_lifelines_power_supply`
--

INSERT INTO `tbl_lifelines_power_supply` (`id`, `area`, `date_time_interruption`, `date_time_restored`, `remarks`) VALUES
(1, '123', '2023-06-14T04:50', '2023-06-24T04:51', '1235');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lifelines_road`
--

CREATE TABLE `tbl_lifelines_road` (
  `id` int(55) NOT NULL,
  `area` varchar(255) NOT NULL,
  `status` varchar(200) NOT NULL,
  `action_taken` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_lifelines_road`
--

INSERT INTO `tbl_lifelines_road` (`id`, `area`, `status`, `action_taken`, `remarks`) VALUES
(1, '321', '321', '321', '32131');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lifelines_water_supply`
--

CREATE TABLE `tbl_lifelines_water_supply` (
  `id` int(55) NOT NULL,
  `area` varchar(255) NOT NULL,
  `date_time_interruption` varchar(200) NOT NULL,
  `date_time_restored` varchar(200) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_lifelines_water_supply`
--

INSERT INTO `tbl_lifelines_water_supply` (`id`, `area`, `date_time_interruption`, `date_time_restored`, `remarks`) VALUES
(1, 'test', '2023-06-22T08:52', '2023-06-23T04:52', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_suspension`
--

CREATE TABLE `tbl_suspension` (
  `id` int(55) NOT NULL,
  `cm` varchar(200) NOT NULL,
  `school` varchar(200) NOT NULL,
  `date_time_suspension` varchar(200) NOT NULL,
  `date_time_resume` varchar(200) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_suspension`
--

INSERT INTO `tbl_suspension` (`id`, `cm`, `school`, `date_time_suspension`, `date_time_resume`, `remarks`) VALUES
(1, 'test', 'test', 'test', 'test', 'test'),
(2, '12345', '1235', '2023-06-21T08:16', '2023-06-22T04:21', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `section`) VALUES
(1, 'user', 'user', 'user', 'user', '$2y$10$MOOOrssDON3cK3b8a6Ehxeu.sQwBhjs86g/H0G2.T9lV6q2ooQuxO', 'user'),
(2, 'awa', 'awa', 'awa', 'awa', 'awa', 'awa'),
(3, 'pogi', 'miguelfranz', '321', '1231', '1231', 'NULL'),
(4, 'tests', 'tests', '123', '123', '$2y$10$/54ZhDq7pcaQv6diqOBRUujk/.8mOqLB5btN5ZL6ErmGNAZoMd8JC', 'NULL'),
(6, '1111', '1111', '1111', '1111', '$2y$10$QsG0B/7srErvncV0YusKCueDrR4eH85Rm.fGQwOuh6Rcud0U5BBBu', 'NULL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accident`
--
ALTER TABLE `tbl_accident`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin_damages`
--
ALTER TABLE `tbl_admin_damages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_casualties`
--
ALTER TABLE `tbl_casualties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_covid19`
--
ALTER TABLE `tbl_covid19`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_damages`
--
ALTER TABLE `tbl_damages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_disaster`
--
ALTER TABLE `tbl_disaster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lifelines_communication`
--
ALTER TABLE `tbl_lifelines_communication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lifelines_dam`
--
ALTER TABLE `tbl_lifelines_dam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lifelines_power_supply`
--
ALTER TABLE `tbl_lifelines_power_supply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lifelines_road`
--
ALTER TABLE `tbl_lifelines_road`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_lifelines_water_supply`
--
ALTER TABLE `tbl_lifelines_water_supply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_suspension`
--
ALTER TABLE `tbl_suspension`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accident`
--
ALTER TABLE `tbl_accident`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_admin_damages`
--
ALTER TABLE `tbl_admin_damages`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_casualties`
--
ALTER TABLE `tbl_casualties`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_covid19`
--
ALTER TABLE `tbl_covid19`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_damages`
--
ALTER TABLE `tbl_damages`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_disaster`
--
ALTER TABLE `tbl_disaster`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_lifelines_communication`
--
ALTER TABLE `tbl_lifelines_communication`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_lifelines_dam`
--
ALTER TABLE `tbl_lifelines_dam`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_lifelines_power_supply`
--
ALTER TABLE `tbl_lifelines_power_supply`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_lifelines_road`
--
ALTER TABLE `tbl_lifelines_road`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_lifelines_water_supply`
--
ALTER TABLE `tbl_lifelines_water_supply`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_suspension`
--
ALTER TABLE `tbl_suspension`
  MODIFY `id` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
