<?php
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
     <script src="https://kit.fontawesome.com/your-font-awesome-kit.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dental Clinic</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
  .fa-inverse {
            color: #7975fe !important;
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }


</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('admin_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>

           <?php
           $res = mysqli_query($conn, "SELECT COUNT(id) AS total_records FROM tbl_covid19");
           if ($res) {
             $row = mysqli_fetch_assoc($res);
             $totalRecords = $row['total_records'];
           } else {
             $totalRecords = 0; // Default value if the query fails
           }
           ?>


           <?php
           $res = mysqli_query($conn, "SELECT COUNT(id) AS total_accident FROM tbl_accident");
           if ($res) {
             $row = mysqli_fetch_assoc($res);
             $totalAccidents = $row['total_accident'];
           } else {
             $totalAccidents = 0; // Default value if the query fails
           }
           ?>


           <?php
           $res = mysqli_query($conn, "SELECT COUNT(id) AS total_disaster FROM tbl_disaster");
           if ($res) {
             $row = mysqli_fetch_assoc($res);
             $totalDisaster = $row['total_disaster'];
           } else {
             $totalDisaster = 0; // Default value if the query fails
           }
           ?>


           <?php
           $res = mysqli_query($conn, "SELECT COUNT(id) AS total_suspension FROM tbl_suspension");
           if ($res) {
             $row = mysqli_fetch_assoc($res);
             $totalSuspensions = $row['total_suspension'];
           } else {
             $totalSuspensions = 0; // Default value if the query fails
           }
           ?>






                <h1>Dashboard</h1><br>
                <div class="row justify-content-center">

                    <div class="col-lg-6 mb-2">
                       <div class="card">
                         <div class="card-body">
                           <h5 class="card-title">Total Covid 19 Patients</h5>
                           <!-- <h6 class="card-subtitle mb-2 text-muted">Card Subtitle</h6> -->
                           <p class="card-text">Some example text.</p>
                           <div class="card-number">
                             <h1><?php echo $totalRecords; ?></h1>
                           </div>
                         </div>
                    </div>
                    </div>



                    <div class="col-lg-6 mb-2">
                       <div class="card">
                         <div class="card-body">
                           <h5 class="card-title">Total Accidents</h5>
                           <!-- <h6 class="card-subtitle mb-2 text-muted">Card Subtitle</h6> -->
                           <p class="card-text">Some example text.</p>
                           <div class="card-number">
                             <h1><?php echo $totalAccidents; ?></h1>
                           </div>
                         </div>
                       </div>
                    </div>  


                    <div class="col-lg-6 mb-2">
                       <div class="card">
                         <div class="card-body">
                           <h5 class="card-title">Total Disaster</h5>
                           <!-- <h6 class="card-subtitle mb-2 text-muted">Card Subtitle</h6> -->
                           <p class="card-text">Some example text.</p>
                           <div class="card-number">
                             <h1><?php echo $totalDisaster; ?></h1>
                           </div>
                         </div>
                    </div>
                    </div>



                    <div class="col-lg-6 mb-2">
                       <div class="card">
                         <div class="card-body">
                           <h5 class="card-title">Total Suspension</h5>
                           <!-- <h6 class="card-subtitle mb-2 text-muted">Card Subtitle</h6> -->
                           <p class="card-text">Some example text.</p>
                           <div class="card-number">
                             <h1><?php echo $totalSuspensions; ?></h1>
                           </div>
                         </div>
                       </div>
                    </div>  

                    

                 

                 






                 <!--  <div class="col-lg-12 text-center">
                    <a href="secretary_dashboard_online_client_records.php"><button class="btn btn-success" style="height: 80px; font-size: 24px; margin-right: 105px;">Online Client Records</button></a>
                     <a href="secretary_dashboard_walkin_client_records.php"><button class="btn btn-primary" style="height: 80px; font-size: 24px;">Walk-In Client Records</button></a>
                  </div>  -->
                </div>
            </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>


