<style>
    .list-group-item{
        border:  1px solid white;
    }

    .list-group-item-light {
        color:  #41464b;
    }

    #sidebar-wrapper {
        background: #f9f9f9 !important;
    }

    .list-group-item {
        background: #f9f9f9;
        color:  #7975fe;
        border: solid 5px #f0f0f0;
        zoom:  100%;
    }

    .list-group-item:hover {
        background: #7975fe;
        color:  white;

    }

    .list-group-item.active {
  background-color: #007bff;
  border-color: #007bff;
}


    hr {


  border-top: 1px solid rgba(0, 0, 0, 0.1);
}
    
</style>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<div class="border-end" id="sidebar-wrapper"> 
<div class="sidebar-heading " style="font-weight: bold; color: #7975fe; background: #f9f9f9;"> 
     HMIS
 </div> 
    <div class="list-group list-group-flush">
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_dashboard.php') !== false) echo 'active'; ?>" href="admin_dashboard.php">
        <!-- Speedometer -->          
        &nbsp; Dashboard
      </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_manage_users.php') !== false) echo 'active'; ?>" href="admin_manage_users.php">
        &nbsp; Users
      </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_covid19.php') !== false) echo 'active'; ?>"   href="admin_covid19.php">
        &nbsp; Covid 19
      </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_accident.php') !== false) echo 'active'; ?>" href="admin_accident.php">
        &nbsp; Accident
      </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_disaster.php') !== false) echo 'active'; ?>" href="admin_disaster.php">
        &nbsp; Disaster
      </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_casualties.php') !== false) echo 'active'; ?>" href="admin_casualties.php">
        &nbsp; Casualties
      </a>
      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_suspension.php') !== false) echo 'active'; ?>" href="admin_suspension.php">
        &nbsp; Suspension
      </a>

     <!--  <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_lifelines.php') !== false) echo 'active'; ?>" href="admin_lifelines.php">
        &nbsp; Lifelines
      </a> -->

      <a class="list-group-item list-group-item-action p-3" data-toggle="collapse" href="#forms-submenu">
           &nbsp; Lifelines <i class="fa fa-angle-down"></i>
      </a>

      <div class="collapse" id="forms-submenu">


            <a class="list-group-item list-group-item-action <?php if(strpos($_SERVER['PHP_SELF'], 'admin_lifelines_dam.php') !== false) echo 'active'; ?>" href="admin_lifelines_dam.php">
                &nbsp; Dam
            </a>
            <a class="list-group-item list-group-item-action <?php if(strpos($_SERVER['PHP_SELF'], 'admin_lifelines_road.php') !== false) echo 'active'; ?>" href="admin_lifelines_road.php">
                &nbsp; Road/Bridges
            </a>  


           <a class="list-group-item list-group-item-action <?php if(strpos($_SERVER['PHP_SELF'], 'admin_lifelines_power_supply.php') !== false) echo 'active'; ?>" href="admin_lifelines_power_supply.php">
               &nbsp; Power Supply
           </a> 



           <a class="list-group-item list-group-item-action <?php if(strpos($_SERVER['PHP_SELF'], 'admin_lifelines_communication.php') !== false) echo 'active'; ?>" href="admin_lifelines_communication.php">
               &nbsp; Communications
           </a> 
           <a class="list-group-item list-group-item-action <?php if(strpos($_SERVER['PHP_SELF'], 'admin_lifelines_water_supply.php') !== false) echo 'active'; ?>" href="admin_lifelines_water_supply.php">
               &nbsp; Water Supply
           </a> 





       </div> 



      <a class="list-group-item list-group-item-action p-3 <?php if(strpos($_SERVER['PHP_SELF'], 'admin_damages.php') !== false) echo 'active'; ?>" href="admin_damages.php">
        &nbsp; Damages
      </a>
    </div>
</div>

