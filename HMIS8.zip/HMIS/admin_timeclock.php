<?php 

include('connection.php'); // Always include this to create connection to database
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Monitoring System</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"> <!-- stylesheet for bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- stylesheet for log in -->
</head>
<style>
    .color-hov {
        background: #7975fe; 
        border-color: #7975fe;
    }
    .color-hov:hover {
        background: #504ce1;
        border-color: #504ce1;
    }
</style>
<body>


<div class="container" style="max-width: 800px; margin-top: 100px;">
    <a href="index.php"><button class="btn btn-primary color-hov">Back</button></a>
    <br><br>
  <div class="lineBorder"> <!-- Class for Line border -->
    <br>    
     <!-- <?php
                  // Check if the success message is set in the session and display it
                  if (isset($_SESSION['success'])) {
                      echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
                      unset($_SESSION['success']); // Clear the success message from the session
                  }
                  else if (isset($_SESSION['danger'])) {
                      echo '<div class="alert alert-danger">' . $_SESSION['danger'] . '</div>';
                      unset($_SESSION['danger']); // Clear the success message from the session
                  }

                  ?> -->




                  <?php
                  // Assuming you have established a database connection

                  // Check if the 'timeIn' button was clicked
                  if (isset($_POST['timeIn'])) {
                      $employee_no = $_POST['employee_no'];
                      $password = $_POST['password'];

                      // Validate employee credentials
                      $query = "SELECT * FROM tbl_employee_credentials WHERE employee_no = '$employee_no' AND password = '$password'";
                      $result = mysqli_query($conn, $query);
                      
                      if (mysqli_num_rows($result) > 0) {
                          $current_date = date('Y-m-d');
                          $current_time = date('H:i:s');
                          
                          // Check if the user has already clocked in for the current date
                          $check_query = "SELECT * FROM tbl_attendance WHERE employee_no = '$employee_no' AND date_attendance = '$current_date' LIMIT 1";
                          $check_result = mysqli_query($conn, $check_query);
                          
                          if (mysqli_num_rows($check_result) > 0) {

                               echo '<div class="alert alert-danger">Youve already clocked in!</div>';

                          } else {
                              // Insert the time in record into tbl_attendance
                              $insert_query = "INSERT INTO tbl_attendance (employee_no, time_in, date_attendance, status) VALUES ('$employee_no', '$current_time', '$current_date', 'IN')";
                              mysqli_query($conn, $insert_query);

                               if($insert_query) {
      
                                   echo '<div class="alert alert-success">Youve been logged in successfully.</div>';
                               }

                          }
                      } else {
 
                             echo '<div class="alert alert-danger">Invalid employee credentials!</div>';
                      }
                  }

                  // Check if the 'timeOut' button was clicked
                  if (isset($_POST['timeOut'])) {
                      $employee_no = $_POST['employee_no'];
                      $password = $_POST['password'];

                      // Validate employee credentials
                      $query = "SELECT * FROM tbl_employee_credentials WHERE employee_no = '$employee_no' AND password = '$password'";
                      $result = mysqli_query($conn, $query);
                      
                      if (mysqli_num_rows($result) > 0) {
                          $current_date = date('Y-m-d');
                          $current_time = date('H:i:s');
                          
                          // Check if the user has already clocked out for the current date
                          $check_query = "SELECT * FROM tbl_attendance WHERE employee_no = '$employee_no' AND date_attendance = '$current_date' AND status = 'OUT' LIMIT 1";
                          $check_result = mysqli_query($conn, $check_query);
                          
                          if (mysqli_num_rows($check_result) > 0) {
                                echo '<div class="alert alert-danger">Youve already clocked out!</div>';
                          } else {
                              // Update the latest time in record with the time out and status
                              $update_query = "UPDATE tbl_attendance SET time_out = '$current_time', status = 'OUT' WHERE employee_no = '$employee_no' AND date_attendance = '$current_date' ORDER BY id DESC LIMIT 1";
                              mysqli_query($conn, $update_query);
                              
                              if($update_query){
                                  // $_SESSION['success'] = "You've been logged out successfully.";

                                  echo '<div class="alert alert-success">Youve been logged out successfully.</div>';
                              }



                          }
                      } else {
                          echo "Invalid employee credentials!";
                           echo '<div class="alert alert-danger">Invalid employee credentials!</div>';
                      }
                  }

                  // Close the database connection
                  mysqli_close($conn);
                  ?>



        <div class="row">
           
            <div class="col-lg-6">
                <img src="img/clock.png" class="loginDesign img-fluid" >
            </div>
                <div class="col-lg-6" style="margin-top: 50px;">
                    <?php include ('time.php'); ?>
                <form action="" method="post">

                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="time_in"/>

                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date('h:i:s');?>" name="time_out"/>

                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Manila'); echo date("F d, Y");?>" name="date_attendance"/>

                    <div class="form-group-sm">
                        <input type="text" name="employee_no" style="height: 40px; font-size: 15px;" placeholder="Employee No." class="form-control mt-3 form-control-sm"  required>
                        <input type="password" name="password" style="height: 40px; font-size: 15px;" placeholder="Password" class="form-control form-control-sm mt-2" required>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px;">
                                <span><input type="submit" style="display: block; width: 100% !important;" class="btn btn-block btn-primary color-hov" value="IN" name="timeIn"></span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 10px; ">
                                <span><input type="submit" style="display: block; width: 100% !important;" class="btn btn-block btn-primary color-hov" value="OUT" name="timeOut"></span>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="text-center">
                        <a href="student_register.php">No account? Click this to sign up.</a>
                    </div> -->
                    <!-- There's no registration here because it's on teacher side and confidential -->

                </form>
            </div>
        </div>
        <br>
    </div>
</div>




</body>
</html>
