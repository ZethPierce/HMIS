<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
     <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>HMIS</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
      .shadow {
        box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.15)!important;
        margin: 15px;
/*        padding: 15px;*/
    }
  .fa-inverse {
            color: #7975fe !important;
        }

        .card {
          border: 1px solid rgba(0,0,0,.06);
          box-shadow: 0 10px 40px 0 rgb(62 57 107 / 7%), 0 2px 9px 0 rgb(62 57 107 / 6%);
        }


</style>
<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <?php 
            include('admin_sidebar.php');
         ?>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
          <?php 
            include('header.php');
         ?>  
            <!-- Page content-->
            <div class="container-fluid"><br>
                <h1>Dashboard</h1><br>
                <div class="chartCard">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    
                                      <div class="shadow">
                                        <div class="card-header bg-danger text-white">
                                            <h4>Total Accident</h4>
                                        </div>
                                        <div class="card-body">
                                        Custom Date: 
                                              <input type="date" onchange="startDateFilter(this)">
                                              <input type="date" onchange="endDateFilter(this)"> 
                                              <button onclick="reset(this)">Reset</button>&nbsp;
                                              Filter By Month and Year:
                                              <select onchange="filterChart(this)">
                                                  <option value="1">1 Month</option>
                                                  <option value="12">12 Months</option>
                                              </select>
                                              <!-- <input type="month" onchange="filterChart(this)"> -->
                                              <canvas id="myChartLine" height="85"></canvas>   
                                          </div>                        
                                      </div>
                                  </div>
                                  
                                  <div class="col-lg-12 col-md-12">
                                      <div class="chartBox shadow">
                                            <div class="card-header bg-danger text-white">
                                                <h4>Total Count Area in Disaster</h4>
                                            </div>
                                            <div style="width: 600px; height: 400px;">
                                                <canvas id="barChart"></canvas>
                                              </div>
                                      </div>
                                  </div>


 


                            </div>
                        </div>

                        <?php
                        // Connect to the database
                             $conn = mysqli_connect("localhost", "root", "", "hmis_db");

                             if (!$conn) {
                                 die("Connection failed: " . mysqli_connect_error());
                             }


                             // Retrieve data from tbl_accident
                             $query = "SELECT area, COUNT(*) AS total FROM tbl_disaster GROUP BY area";
                             $result = mysqli_query($conn, $query);

                             $labels = [];
                             $data = [];

                             while ($row = mysqli_fetch_assoc($result)) {
                                 $labels[] = $row['area'];
                                 $data[] = $row['total'];
                             }

                             // Close the database connection







                             $sql = "SELECT time_date, COUNT(*) AS total FROM tbl_accident GROUP BY time_date";
                             $result = mysqli_query($conn, $sql);

                             if (mysqli_num_rows($result) > 0) {
                                 while ($row = mysqli_fetch_assoc($result)) {
                                     $dateArray[] = $row["time_date"];
                                     $totalArray[] = $row["total"];
                                 }

                                 mysqli_free_result($result);
                             } else {
                                 echo 'no result';
                             }


                             mysqli_close($conn);




                            


                      















                           ?>






              

        
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
     <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/luxon@^2"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-luxon@^1"></script>
   
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>
<script>

    const dateArrayJS = <?php echo json_encode($dateArray);?>


    const dateChartJS = dateArrayJS.map((day, index) => {
        let dayjs = new Date(day);
        return dayjs.setHours(0, 0, 0, 0);
    });

        // setup 
        const dataLine = {
          labels: dateChartJS,
          // labels: ['2023-01-01', '2023-02-01', '2023-10-02', '2023-12-01', '2023-12-06'],
          datasets: [{
            label: 'Total Accidents',
            data: <?php echo json_encode($totalArray);?>,
            // data: [18, 12, 6, 9, 12, 3, 9],
            backgroundColor: [
                'rgba(255, 99, 132, 1)', 
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)', 
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)'
            ],
            borderColor: [
              'rgb(153, 102, 255, 1)',
            ],
            borderWidth: 2
          }]
        };

        // config 
        const configLine = {
          type: 'line',
          data: dataLine,  //shorthand
          options: {
            // autoSkip: false,
            scales: {
              x: {            
                type: 'time', 
                time: {
                    unit: 'day'
                },
              },
              y: {
                beginAtZero: true
              }
            }
          }
        };

        // render init block
        const myChartLine = new Chart(
          document.getElementById('myChartLine'),
          configLine
        );


        function startDateFilter(date) {
          const startDate = new Date(date.value);
          myChartLine.config.options.scales.x.min = startDate.setHours(0, 0, 0, 0);
          myChartLine.update();
        }

        function endDateFilter(date) {
          const endDate = new Date(date.value);
          myChartLine.config.options.scales.x.max = endDate.setHours(0, 0, 0, 0);
          myChartLine.update();
        }


        function filterChart(months) {
          myChartLine.config.options.scales.x.min = luxon.DateTime.now().plus({months: -months.value}).toISODate();
          myChartLine.config.options.scales.x.max = luxon.DateTime.now().toISODate();
          myChartLine.update();
        }

        function reset(date) {
          const startDate = new Date(date.value);
          const endDate = new Date(date.value);
          myChartLine.config.options.scales.x.min = startDate.setHours(0, 0, 0, 0);
          myChartLine.config.options.scales.x.max = endDate.setHours(0, 0, 0, 0);
          myChartLine.update();
          console.log(myChartLine.config.options.scales.x.max);
        }

        const day = [
          {
             x: Date.parse(<?php echo json_encode($dateArray);?>), 
             y: parseInt(<?php echo json_encode($totalArray);?>)
          }
        ];
        const week = [
          {
             x: Date.parse(<?php echo json_encode($dateArray);?>), 
             y: parseInt(<?php echo json_encode($totalArray);?>)
          }
        ];
        const month = [
          {
             x: Date.parse(<?php echo json_encode($dateArray);?>), 
             y: parseInt(<?php echo json_encode($totalArray);?>)
          }
        ];


        function timeFrame(period) {
          if(period.value =='day') {
            myChartLine.config.options.scales.x.time.unit = period.value;
            myChartLine.config.data.datasets[0].data = day;
            
          }
           if(period.value =='week') {
            myChartLine.config.options.scales.x.time.unit = period.value;
            myChartLine.config.data.datasets[0].data = week;
            
          }
           if(period.value =='month') {
            myChartLine.config.options.scales.x.time.unit = period.value;
            myChartLine.config.data.datasets[0].data = month;

          }
          myChartLine.update();

        }





</script>


<script>
    // Sample data
  var data = {
       labels: <?php echo json_encode($labels); ?>,
       datasets: [{
         label: 'Accident Areas',
         data: <?php echo json_encode($data); ?>,
           backgroundColor: [
                'rgba(255, 99, 132, 1)', 
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)', 
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)'
            ],
         borderColor: 'rgba(54, 162, 235, 1)',
         borderWidth: 1
       }]
     };

    // Chart configuration
    var options = {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    };

    // Get the canvas element
    var ctx = document.getElementById('barChart').getContext('2d');

    // Create the bar chart
    var barChart = new Chart(ctx, {
      type: 'bar',
      data: data,
      options: options
    });
  </script>




                     <?php
                        

                     ?> 

