<?php 
  // $conn = mysqli_connect("localhost", "u742830210_ml2101384", "@Sandra032419", "u742830210_gabay_db");
          

  $conn = mysqli_connect("localhost", "root", "", "hmis_db");

?>