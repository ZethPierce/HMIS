<?php 
include('connection.php');
include('tags.php');

session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>HMIS</title>
    <style>
@font-face {
  font-family: 'Poppins', sans-serif;
  src: url('fonts/Poppins-Regular.otf');
}
 *{
  font-family: 'Poppins', sans-serif;
}


 body {
    background: white;
     overflow-x: hidden !important;
     overflow-y: hidden !important;
 }
 .fontStyle{
  font-family: 'Poppins', sans-serif;

}

img {
  vertical-align: middle;
  border-style: none;
}

 .box {
    display: table;
    width: 100%;
    height: 100vh;
    background: white;

    
}
.box-cell {
    display: table-cell;
    vertical-align: middle;
    
}


.btn-home {
  background-color: #7975fe !important;
  border-color: #7975fe !important;
}

.btn-home:hover {
  background-color: #005eb3 !important;
  border-color: #005eb3 !important;
}


.grad {
     background-image: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1));
}

.login-box-cell {
    width: 450px;
    margin: auto;
    
    padding: 15px; 
}
.login-panel {
   box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.12), 0 1px 5px 0 rgba(0,0,0,0.2); 
    padding: 30px;
    border-radius: 6px;
}
.alertClass {
   width: 100% !important;
   padding: -15px !important;
}

@media (min-width:320px)  { /* smartphones, portrait iPhone, portrait 480x320 phones (Android) */ }
@media (min-width:480px)  { /* smartphones, Android phones, landscape iPhone */ }
@media (min-width:600px)  { /* portrait tablets, portrait iPad, e-readers (Nook/Kindle), landscape 800x480 phones (Android) */ }
@media (min-width:801px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */ }
@media (max-width:1025px) {  body {overflow: scroll !important;} .d-none-pic {display:none;}     /* big landscape tablets, laptops, and desktops */ }
@media (min-width:1281px) { /* hi-res laptops and desktops */ }
</style>
</head>
<body>
<div class="row h-100 fontStyle">
    <div class="col-lg-6">
        <div class="box" >
            <div class="box-cell" >  
                <div style="margin-bottom: 80px;" class="row" style=" ">                               
                        <!-- <div style="display: inline-block; font-size: 2rem; margin-left: 100px;">PATIENTS RECORD MANAGEMENT SYSTEM</div> -->
                          <div style="display: inline-block; font-size: 2rem; margin-left: 100px;">
                            <a href="index.php"><button class="btn btn-primary">Back</button></a>
                        </div> 
                </div>
                <div class="login-box-cell">
                    <div class="login-panel" style="margin-bottom: 150px;">
                        <div class="row lead" style="margin-left:0px; font-size: 18px;">
                            LOG IN AS USER
                    </div>
                    <br>
                    <h6 class="text-center lead" style="font-size: 1.5rem;  font-weight: bold; margin-top: -40px;"></h6>
                    
                    <h6 class="text-center lead" style="font-size: 15px;"></h6>
                        <form action="" method="post">
                        <div class="form-group-lg">
                            <h6 for="username" style="font-size: 17px;">Username:</h6>
                            <input type="text" name="username"  class="form-control form-control-lg mb-4" maxlength="11" required>
                        </div>
                        <div class="form-group-lg" style="margin-top: 25px;">
                            <h6 for="password" style="font-size: 17px;">Password:</h6>
                            <input type="password" name="password"  class="form-control form-control-lg" maxlength="11" required>
                        </div>
                          <div class="form-group-lg mb-4" style="margin-top: 25px;">
                        <span><input type="submit" class="btn btn-block btn-primary btn-home" style="border-radius: 50px; font-size: 22px; " value="Log In" name="login"></span>
                        </form>
               

                        
                        </div>
                      
                        <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 14px;">
                        
                       </div>
                        <?php 
                            if(isset($_POST["login"]))
                            {
                                // variable naman to para ma-validate niya yung username at password na iinput mo sa page
                                $count = 0;    
                                $username = $_POST['username'];  // So ito naman, mag-dedeclare ka ng variable $username para sa $_POST['username']  
                                $password = $_POST['password'];  // same lang din dito

                                //dito, mag-eexecute ka na ng query.
                                //so first, magdedeclare ka muna ng variable para sa i-eexecute mong query. so, $res ang name ng variable mo.
                                //so pwede mo na gamitin yung $res given sa example sa baba.
                                // So, icacall mo yung $db kasi ito yung variable para ma-connect siya sa database. Nasa connection.php yan.
                                // So, mysqli_query($db, then sa loob nito yung query mo. "SELECT * FROM kung anong table name mo")
                                // WHERE kung saan mo naman siya i-eexecute
                                $res = mysqli_query($conn, "SELECT * FROM tbl_user_credentials WHERE username='$username' && password='$password'");

                                // so based dito, yung mysqli_num_rows nagrereturn siya ng number ng rows sa magiging result ng query mo
                                $count = mysqli_num_rows($res); 
                                                                
                                // so if yung $count nya is 0 or wala yung username or password nya sa table, i-eexecute nya yung laman ng echo
                                // which is yung alert na mali yung nilagay nyang input                              
                                if($count == 0) { 
                                    
                                echo '<div class="alert alert-danger alertClass">
                                    
                                <center>
                              <!--  <button type="button" class="close" data-dismiss="alert">&times;</button> -->
                                
                                <strong>Invalid</strong> Username Or Password.
                                </center>
                                    </div> ';

                                }
                                // so kapag tama naman yung nilagay nya, i-eexecute nya ulit yung nasa loob ng echo 
                                // which is mapupunta na siya sa index.php na page.
                                else { 
                                    $_SESSION["username"] = $username;
                                    
                                echo '<script>
                                        window.location="user_index.php";
                                    </script> ';
                                
                                }
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 hide-lg d-none-pic grad">
        <img src="img/acad_wallpaper2.png"  
        style="height: 100vh !important; 
        zoom: 100%; 
     object-fit: none;  
object-position: right top;  

        overflow-y: none; 
       

    "/>
    </div>
</div>
</body>
</html>

<script>
/* Optional but not required 
$("#alert-success").fadeTo(2000, 500).slideUp(500, function(){
    $("#alert-success").slideUp(500);
});
$("#alert-danger").fadeTo(5000, 500).slideUp(500, function(){
    $("#alert-danger").slideUp(500);
});
*/
</script>