<style>
    .list-group-item{
        border:  1px solid white;
    }

    .list-group-item-light {
        color:  #41464b;
    }

    #sidebar-wrapper {
        background: #f9f9f9 !important;
    }

    .list-group-item {
        background: #f9f9f9;
        color:  #7975fe;
        border: solid 5px #f0f0f0;
        zoom:  100%;
    }

    .list-group-item:hover {
        background: #7975fe;
        color:  white;

    }

    hr {


  border-top: 1px solid rgba(0, 0, 0, 0.1);
}
    
</style>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<div class="border-end" id="sidebar-wrapper"> 
<div class="sidebar-heading " style="font-weight: bold; color: #7975fe; background: #f9f9f9;"> 
     HMIS
 </div> 
    <!--  <div class="sidebar-heading " style="font-weight: bold; color: #7975fe; background: #f9f9f9; margin-left: -20px;"> 
    <img src="assets/img/gabaylogo2.png" class="img-fluid" width="70" height="70"  alt="">
     GABAY</div>  -->
     <!-- border-bottom -->
    <div class="list-group list-group-flush">
        <a class="list-group-item list-group-item-action p-3" href="admin_dashboard.php">
            <!-- Speedometer -->          
            &nbsp; Dashboard
        </a>
        <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Users
        </a>
        <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Notification
        </a>
        <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Accident
        </a>
        <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Disaster
        </a>
        <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Disaster / Incident / Casualties
        </a>
         <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Suspension of Classes / Work in Government
        </a>
         <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Status of Liflines
        </a>
         <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Damage Houses
        </a>
         <a class="list-group-item list-group-item-action p-3" href="admin_manage_users.php">
            &nbsp; Transportation
        </a>

       
        <hr/>







    </div>
</div>

