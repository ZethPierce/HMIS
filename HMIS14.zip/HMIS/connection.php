<?php 
          

  $conn = mysqli_connect("localhost", "root", "", "hmis_db");

?>