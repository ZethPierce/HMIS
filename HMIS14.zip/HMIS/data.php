<?php

include('connection.php');
$hexa = array(
    "(255, 99, 132, 1)",
    "(54, 162, 235, 1)",
    "(255, 206, 86, 1)",
    "(75, 192, 192, 1)",
    "(153, 102, 255, 1)",
    "(255, 159, 64, 1)",
    "(255, 99, 132, 1)",
    "(54, 162, 235, 1)",
    "(255, 99, 132, 1)",
    "(54, 162, 235, 1)"
);

if (isset($_POST["action"])) {

    if ($_POST["action"] == 'name') {
        $query = "SELECT *, count(d.id) as total, d.name as name FROM bookings LEFT JOIN destination d ON d.id = bookings.destination_id GROUP BY d.name ORDER BY d.id DESC ";

        $result = mysqli_query($conn, $query);

        $data = array();

        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = array(
                'name'       => $row["name"],
                'total'      => $row["total"],
                'color'      => 'rgba' . $hexa[array_rand($hexa)] . ''
            );
        }

        echo json_encode($data);
    }
}

// $query = "SELECT *, count(d.id) as total, d.name as name FROM bookings LEFT JOIN destination d ON d.id = bookings.destination_id WHERE d.category_id = 1 GROUP BY d.name ORDER BY d.id DESC ";
?>
