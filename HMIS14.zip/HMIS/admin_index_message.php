<?php 
  include('connection.php');
session_start();

if (isset($_GET['userId'])) {
    $_SESSION['userId'] = $_GET['userId'];
    header("location: admin_messenger.php");
}

 
  $username_session = $_SESSION['username']; //getting information of the user

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>HMIS</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
  <div class="d-flex" id="wrapper">
    <?php 
    include('admin_sidebar.php');
   ?>
          <div id="page-content-wrapper">
          <?php
            include('header.php');
          ?>

<div class="container  bg-white fontStyle " style="margin-top: 50px !important;">
  <div class="row ">


<div class="col-md-4">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4>
                  Please select your account
              </h4>
          </div>

          <div class="modal-body" >
              <ol>
                  <?php 
                    $users = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials");

                    while($user = mysqli_fetch_assoc($users)) 
                    {
                      echo '
                      <li>
                          <a href="admin_index_message.php?userId='.$user["id"].'">'.$user["username"].'</a>
                      </li>
                      ';
                    }

                  ?>




              </ol>
          </div>
 


      </div>
  </div>
</div>




</div>

</div>
</body>

<script>
    $(document).ready(function(){
        $("#send").on("click", function() {
            url: "insertMessage.php";
            method: "POST", 
            data: {
              fromUser: $("#fromUser").val();
              toUser: $("#toUser").val();
              message: $("#message").val();
            },
            dateType: "text",
            success:function(data) {
                $("#message").val("");
            }
        })
    })
</script>






</html>
 <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>

<script>

  // hide and show password
function showPass(pass_id,icon_element) {
  var x = document.getElementById(pass_id);
  var iconChange = document.getElementById("changeIcon");

  if (x.type === "password") {
    x.type = "text";
    icon_element.innerHTML = "<i class='fa fa-eye-slash'></i>";

  } else {
    x.type = "password";
    icon_element.innerHTML = "<i class='fa fa-eye'></i>";
  }
}

</script>